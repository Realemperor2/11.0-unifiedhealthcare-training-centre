"use client"

import { useState, useRef } from 'react'
import { Canvas, useFrame, ThreeElements } from '@react-three/fiber'
import { OrbitControls, useGLTF, PerspectiveCamera } from '@react-three/drei'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { AIDesignAssistant } from './AIDesignAssistant'
import * as THREE from 'three'

type ComponentType = 'conveyor' | 'robot' | 'sensor' | 'workstation' | 'storage' | 'qc'

interface ProductionComponent {
  id: string
  type: ComponentType
  position: [number, number, number]
  rotation: [number, number, number]
  settings: Record<string, any>
}

function ProductionLine({ components }: { components: ProductionComponent[] }) {
  return (
    <>
      {components.map((component) => {
        switch (component.type) {
          case 'conveyor':
            return <Conveyor key={component.id} {...component} />
          case 'robot':
            return <Robot key={component.id} {...component} />
          case 'sensor':
            return <Sensor key={component.id} {...component} />
          case 'workstation':
            return <Workstation key={component.id} {...component} />
          case 'storage':
            return <Storage key={component.id} {...component} />
          case 'qc':
            return <QualityControl key={component.id} {...component} />
        }
      })}
    </>
  )
}

function Conveyor({ position, rotation, settings }: ProductionComponent) {
  const { nodes, materials } = useGLTF('/models/conveyor.glb')
  const meshRef = useRef<THREE.Mesh>(null)

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.x += 0.01
    }
  })

  return (
    <group position={position} rotation={rotation}>
      <mesh
        ref={meshRef}
        geometry={nodes.Conveyor.geometry}
        material={materials.ConveyorMaterial}
        scale={[settings.length || 1, 1, settings.width || 0.5]}
      />
    </group>
  )
}

function Robot({ position, rotation }: ProductionComponent) {
  const { nodes, materials } = useGLTF('/models/robot_arm.glb')
  const armRef = useRef<THREE.Group>(null)

  useFrame((state) => {
    if (armRef.current) {
      armRef.current.rotation.y = Math.sin(state.clock.elapsedTime) * 0.5
    }
  })

  return (
    <group position={position} rotation={rotation} ref={armRef}>
      <mesh geometry={nodes.Base.geometry} material={materials.RobotMaterial} />
      <mesh geometry={nodes.Arm.geometry} material={materials.RobotMaterial} />
    </group>
  )
}

function Sensor({ position, rotation }: ProductionComponent) {
  const { nodes, materials } = useGLTF('/models/sensor.glb')
  return (
    <group position={position} rotation={rotation}>
      <mesh geometry={nodes.Sensor.geometry} material={materials.SensorMaterial} />
    </group>
  )
}

function Workstation({ position, rotation }: ProductionComponent) {
  const { nodes, materials } = useGLTF('/models/workstation.glb')
  return (
    <group position={position} rotation={rotation}>
      <mesh geometry={nodes.Workstation.geometry} material={materials.WorkstationMaterial} />
    </group>
  )
}

function Storage({ position, rotation, settings }: ProductionComponent) {
  const { nodes, materials } = useGLTF('/models/storage.glb')
  return (
    <group position={position} rotation={rotation}>
      <mesh 
        geometry={nodes.Storage.geometry} 
        material={materials.StorageMaterial}
        scale={[settings.width || 1, settings.height || 1, settings.depth || 1]}
      />
    </group>
  )
}

function QualityControl({ position, rotation }: ProductionComponent) {
  const { nodes, materials } = useGLTF('/models/qc_station.glb')
  return (
    <group position={position} rotation={rotation}>
      <mesh geometry={nodes.QCStation.geometry} material={materials.QCMaterial} />
    </group>
  )
}

export default function ProductionLineDesigner() {
  const [components, setComponents] = useState<ProductionComponent[]>([])
  const [selectedComponent, setSelectedComponent] = useState<ComponentType | ''>('')
  const [componentSettings, setComponentSettings] = useState<Record<string, any>>({})

  const addComponent = () => {
    if (selectedComponent) {
      const newComponent: ProductionComponent = {
        id: `${selectedComponent}-${components.length}`,
        type: selectedComponent,
        position: [components.length * 2 - 2, 0, 0],
        rotation: [0, 0, 0],
        settings: componentSettings
      }
      setComponents([...components, newComponent])
    }
  }

  const saveDesign = () => {
    localStorage.setItem('productionLineDesign', JSON.stringify(components))
    alert('Design saved successfully!')
  }

  const loadDesign = () => {
    const savedDesign = localStorage.getItem('productionLineDesign')
    if (savedDesign) {
      setComponents(JSON.parse(savedDesign))
      alert('Design loaded successfully!')
    } else {
      alert('No saved design found.')
    }
  }

  return (
    <Card className="col-span-2">
      <CardHeader>
        <CardTitle>Production Line Designer</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex space-x-4">
            <Select onValueChange={(value) => setSelectedComponent(value as ComponentType)}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select component" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="conveyor">Conveyor Belt</SelectItem>
                <SelectItem value="robot">Robotic Arm</SelectItem>
                <SelectItem value="sensor">Sensor</SelectItem>
                <SelectItem value="workstation">Workstation</SelectItem>
                <SelectItem value="storage">Storage</SelectItem>
                <SelectItem value="qc">Quality Control</SelectItem>
              </SelectContent>
            </Select>
            {selectedComponent === 'conveyor' && (
              <div className="flex space-x-2">
                <Input
                  type="number"
                  placeholder="Length"
                  onChange={(e) => setComponentSettings({ ...componentSettings, length: parseFloat(e.target.value) })}
                />
                <Input
                  type="number"
                  placeholder="Width"
                  onChange={(e) => setComponentSettings({ ...componentSettings, width: parseFloat(e.target.value) })}
                />
              </div>
            )}
            {selectedComponent === 'storage' && (
              <div className="flex space-x-2">
                <Input
                  type="number"
                  placeholder="Width"
                  onChange={(e) => setComponentSettings({ ...componentSettings, width: parseFloat(e.target.value) })}
                />
                <Input
                  type="number"
                  placeholder="Height"
                  onChange={(e) => setComponentSettings({ ...componentSettings, height: parseFloat(e.target.value) })}
                />
                <Input
                  type="number"
                  placeholder="Depth"
                  onChange={(e) => setComponentSettings({ ...componentSettings, depth: parseFloat(e.target.value) })}
                />
              </div>
            )}
            <Button onClick={addComponent} disabled={!selectedComponent}>Add Component</Button>
          </div>
          <div className="flex space-x-4">
            <Button onClick={saveDesign}>Save Design</Button>
            <Button onClick={loadDesign}>Load Design</Button>
          </div>
          <div className="w-full h-[500px] bg-muted rounded-lg overflow-hidden">
            <Canvas>
              <PerspectiveCamera makeDefault position={[0, 5, 10]} />
              <ambientLight intensity={0.5} />
              <pointLight position={[10, 10, 10]} />
              <ProductionLine components={components} />
              <OrbitControls />
            </Canvas>
          </div>
          <AIDesignAssistant components={components} onSuggestion={(suggestion) => setComponents(suggestion)} />
        </div>
      </CardContent>
    </Card>
  )
}


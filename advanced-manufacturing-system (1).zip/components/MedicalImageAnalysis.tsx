"use client"

import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Canvas } from '@react-three/fiber'
import { OrbitControls, Box, Text } from '@react-three/drei'

function ImageVisualizer() {
  return (
    <Canvas>
      <ambientLight intensity={0.5} />
      <pointLight position={[10, 10, 10]} />
      <Box args={[3, 2, 0.1]} position={[0, 0, 0]}>
        <meshStandardMaterial color="gray" />
      </Box>
      <Text position={[0, 0, 0.1]} fontSize={0.2} color="white">
        Medical Image
      </Text>
      <OrbitControls />
    </Canvas>
  )
}

export function MedicalImageAnalysis() {
  const [file, setFile] = useState<File | null>(null)
  const [analysis, setAnalysis] = useState<string>('')

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFile(e.target.files[0])
    }
  }

  const handleAnalysis = () => {
    // Simulate image analysis with AI
    setAnalysis(`AI Analysis Results:
    - Image Type: ${file?.type}
    - Detected Anomalies: 2
    - Confidence Score: 87%
    - Recommended Action: Consult with specialist
    - Additional Notes: Potential areas of interest identified in upper right quadrant`)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Medical Image Analysis</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Input type="file" onChange={handleFileChange} accept="image/*" />
          <Button onClick={handleAnalysis} disabled={!file}>
            Analyze Image
          </Button>
          {file && (
            <div className="w-full h-[200px] bg-muted rounded-lg overflow-hidden">
              <ImageVisualizer />
            </div>
          )}
          {analysis && (
            <div className="mt-4 p-4 bg-muted rounded-lg">
              <pre className="whitespace-pre-wrap">{analysis}</pre>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}


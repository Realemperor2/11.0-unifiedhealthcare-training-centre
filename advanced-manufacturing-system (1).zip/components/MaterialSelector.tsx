"use client"

import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const materialCategories = [
  'Metals',
  'Polymers',
  'Composites',
  'Ceramics',
  'Glass',
  'Organic Materials',
  'Advanced Materials'
]

const materialTypes: { [key: string]: string[] } = {
  'Metals': ['Aluminum', 'Titanium', 'Steel', 'Copper'],
  'Polymers': ['PLA', 'ABS', 'PETG', 'Nylon', 'PEEK'],
  'Composites': ['Carbon Fiber', 'Fiberglass', 'Custom Blend'],
  'Ceramics': ['Industrial Ceramics'],
  'Glass': ['Transparent Glass', 'Colored Glass'],
  'Organic Materials': ['Bio-inks'],
  'Advanced Materials': ['Graphene', 'Nanomaterials', 'Conductive Inks']
}

export function MaterialSelector() {
  const [category, setCategory] = useState<string>('')
  const [material, setMaterial] = useState<string>('')
  const [quantity, setQuantity] = useState<string>('')
  const [selectedMaterials, setSelectedMaterials] = useState<string[]>([])

  const handleAddMaterial = () => {
    if (category && material && quantity) {
      setSelectedMaterials([...selectedMaterials, `${material} (${quantity} units)`])
      setMaterial('')
      setQuantity('')
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Material Selector</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="category">Material Category</Label>
            <Select onValueChange={setCategory}>
              <SelectTrigger id="category">
                <SelectValue placeholder="Select category" />
              </SelectTrigger>
              <SelectContent>
                {materialCategories.map((cat) => (
                  <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          {category && (
            <div className="space-y-2">
              <Label htmlFor="material">Material Type</Label>
              <Select onValueChange={setMaterial}>
                <SelectTrigger id="material">
                  <SelectValue placeholder="Select material" />
                </SelectTrigger>
                <SelectContent>
                  {materialTypes[category].map((mat) => (
                    <SelectItem key={mat} value={mat}>{mat}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
          
          <div className="space-y-2">
            <Label htmlFor="quantity">Quantity</Label>
            <Input
              id="quantity"
              type="number"
              placeholder="Enter quantity"
              value={quantity}
              onChange={(e) => setQuantity(e.target.value)}
            />
          </div>
          
          <Button onClick={handleAddMaterial}>Add Material</Button>
          
          {selectedMaterials.length > 0 && (
            <div className="mt-4 p-4 bg-muted rounded-lg">
              <h3 className="font-semibold mb-2">Selected Materials:</h3>
              <ul className="list-disc pl-5">
                {selectedMaterials.map((mat, index) => (
                  <li key={index}>{mat}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}


"use client"

import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { apiRequest } from "@/utils/api"

export function ModelDeployment() {
  const [modelId, setModelId] = useState('')
  const [deploymentType, setDeploymentType] = useState('')
  const [deploymentStatus, setDeploymentStatus] = useState('')

  const handleDeployment = async () => {
    setDeploymentStatus('Deployment started...')
    try {
      const response = await apiRequest('/api/deploy-model', 'POST', {
        modelId,
        deploymentType
      })
      setDeploymentStatus(`Deployment complete. Endpoint: ${response.endpoint}`)
    } catch (error) {
      setDeploymentStatus('Deployment failed. Please check your inputs and try again.')
      console.error('Deployment error:', error)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Model Deployment</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="model-id">Model ID</Label>
            <Input
              id="model-id"
              placeholder="Enter model ID"
              value={modelId}
              onChange={(e) => setModelId(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="deployment-type">Deployment Type</Label>
            <Select onValueChange={setDeploymentType}>
              <SelectTrigger id="deployment-type">
                <SelectValue placeholder="Select deployment type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="cloud">Cloud</SelectItem>
                <SelectItem value="edge">Edge Device</SelectItem>
                <SelectItem value="on-premise">On-Premise</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button onClick={handleDeployment}>Deploy Model</Button>
          {deploymentStatus && (
            <div className="mt-4 p-4 bg-muted rounded-lg">
              <p>{deploymentStatus}</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}


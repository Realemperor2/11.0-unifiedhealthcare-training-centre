import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export function InventoryManagement() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Inventory Management</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Input placeholder="Search materials..." />
          <div className="grid grid-cols-2 gap-4">
            <Button>View Inventory</Button>
            <Button variant="outline">Add New Material</Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}


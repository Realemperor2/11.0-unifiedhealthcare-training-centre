"use client"

import { useState } from 'react'
import { Canvas } from '@react-three/fiber'
import { OrbitControls, Box, Text } from '@react-three/drei'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

function Scene() {
  return (
    <>
      <ambientLight intensity={0.5} />
      <pointLight position={[10, 10, 10]} />
      <Box position={[0, 0, 0]} args={[3, 0.2, 5]}>
        <meshStandardMaterial color="gray" />
      </Box>
      <Text position={[0, 1, 0]} fontSize={0.5} color="white">
        Conveyor Belt
      </Text>
      <OrbitControls />
    </>
  )
}

export default function SimulationEnvironment() {
  const [isRunning, setIsRunning] = useState(false)

  return (
    <Card className="col-span-2">
      <CardHeader>
        <CardTitle>Simulation Environment</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="w-full h-[400px] bg-muted rounded-lg overflow-hidden">
            <Canvas>
              <Scene />
            </Canvas>
          </div>
          <Button onClick={() => setIsRunning(!isRunning)}>
            {isRunning ? 'Stop Simulation' : 'Start Simulation'}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}


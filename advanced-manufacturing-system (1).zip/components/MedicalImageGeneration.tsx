"use client"

import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { apiRequest } from "@/utils/api"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Loader2 } from 'lucide-react'

export function MedicalImageGeneration() {
  const [bodyRegion, setBodyRegion] = useState('')
  const [anatomy, setAnatomy] = useState('')
  const [size, setSize] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState('')
  const [error, setError] = useState<string | null>(null)

  const handleGenerate = async () => {
    setLoading(true)
    setError(null)
    try {
      const response = await apiRequest('/maisi', 'POST', {
        body_region: [bodyRegion],
        anatomy_list: [anatomy],
        controllable_anatomy_size: [[anatomy, parseFloat(size)]],
        output_size: [256, 256, 256],
        spacing: [1, 1, 1]
      })
      setResult(JSON.stringify(response, null, 2))
    } catch (error) {
      console.error('Error:', error)
      setError('An error occurred during image generation. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Medical Image Generation (MAISI)</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Select onValueChange={setBodyRegion}>
            <SelectTrigger>
              <SelectValue placeholder="Select body region" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="chest">Chest</SelectItem>
              <SelectItem value="abdomen">Abdomen</SelectItem>
              <SelectItem value="brain">Brain</SelectItem>
            </SelectContent>
          </Select>
          <Input
            placeholder="Enter anatomy (e.g., liver)"
            value={anatomy}
            onChange={(e) => setAnatomy(e.target.value)}
          />
          <Input
            placeholder="Enter size (0-1)"
            value={size}
            onChange={(e) => setSize(e.target.value)}
            type="number"
            min="0"
            max="1"
            step="0.1"
          />
          <Button onClick={handleGenerate} disabled={!bodyRegion || !anatomy || !size || loading}>
            {loading ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Generating...</> : 'Generate Image'}
          </Button>
          {error && (
            <Alert variant="destructive">
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          {result && (
            <div className="mt-4 p-4 bg-muted rounded-lg">
              <pre className="whitespace-pre-wrap">{result}</pre>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}


"use client"

import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { apiRequest } from "@/utils/api"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Loader2 } from 'lucide-react'

export function PalmyraMedQuery() {
  const [query, setQuery] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState('')
  const [error, setError] = useState<string | null>(null)

  const handleQuery = async () => {
    setLoading(true)
    setError(null)
    try {
      const response = await apiRequest('/palmyra_med', 'POST', { prompt: query })
      setResult(response.text)
    } catch (error) {
      console.error('Error:', error)
      setError('An error occurred while processing your query. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Palmyra Med Query</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Textarea
            placeholder="Enter your medical query..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            rows={4}
          />
          <Button onClick={handleQuery} disabled={!query || loading}>
            {loading ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Processing...</> : 'Submit Query'}
          </Button>
          {error && (
            <Alert variant="destructive">
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          {result && (
            <div className="mt-4 p-4 bg-muted rounded-lg">
              <p>{result}</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}


"use client"

import { useState, useEffect } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { apiRequest } from "@/utils/api"

export default function VoiceControlledTutorial() {
  const [isRecording, setIsRecording] = useState(false)
  const [transcript, setTranscript] = useState('')
  const [tutorial, setTutorial] = useState('')

  const startRecording = () => {
    setIsRecording(true)
    // In a real implementation, we would start recording here
  }

  const stopRecording = async () => {
    setIsRecording(false)
    // In a real implementation, we would stop recording and send the audio file to the server
    // For this example, we'll simulate it with a timeout
    setTimeout(async () => {
      try {
        const speechData = await apiRequest('/speech_recognition', 'POST', { audio: 'base64_audio_data_here' })
        setTranscript(speechData.text)

        // Generate tutorial based on transcript
        const tutorialData = await apiRequest('/generate_text', 'POST', { prompt: `Create a brief tutorial about ${speechData.text}` })
        setTutorial(tutorialData.text)
      } catch (error) {
        console.error('Error:', error)
        setTranscript('An error occurred during speech recognition.')
        setTutorial('')
      }
    }, 2000)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Voice-Controlled Tutorial</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Button onClick={isRecording ? stopRecording : startRecording}>
            {isRecording ? 'Stop Recording' : 'Start Recording'}
          </Button>
          {transcript && (
            <div className="mt-4">
              <h4 className="font-semibold">You said:</h4>
              <p>{transcript}</p>
            </div>
          )}
          {tutorial && (
            <div className="mt-4">
              <h4 className="font-semibold">Tutorial:</h4>
              <p>{tutorial}</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}


"use client"

import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { apiRequest } from "@/utils/api"

export function AIModelDevelopment() {
  const [modelType, setModelType] = useState('')
  const [datasetUrl, setDatasetUrl] = useState('')
  const [hyperparameters, setHyperparameters] = useState('')
  const [trainingStatus, setTrainingStatus] = useState('')

  const handleTraining = async () => {
    setTrainingStatus('Training started...')
    try {
      const response = await apiRequest('/api/train-model', 'POST', {
        modelType,
        datasetUrl,
        hyperparameters: JSON.parse(hyperparameters)
      })
      setTrainingStatus(`Training complete. Model ID: ${response.modelId}`)
    } catch (error) {
      setTrainingStatus('Training failed. Please check your inputs and try again.')
      console.error('Training error:', error)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>AI Model Development</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="model-type">Model Type</Label>
            <Select onValueChange={setModelType}>
              <SelectTrigger id="model-type">
                <SelectValue placeholder="Select model type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="classification">Classification</SelectItem>
                <SelectItem value="regression">Regression</SelectItem>
                <SelectItem value="nlp">Natural Language Processing</SelectItem>
                <SelectItem value="computer-vision">Computer Vision</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="dataset-url">Dataset URL</Label>
            <Input
              id="dataset-url"
              placeholder="Enter dataset URL"
              value={datasetUrl}
              onChange={(e) => setDatasetUrl(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="hyperparameters">Hyperparameters (JSON)</Label>
            <Textarea
              id="hyperparameters"
              placeholder='{"learning_rate": 0.01, "batch_size": 32}'
              value={hyperparameters}
              onChange={(e) => setHyperparameters(e.target.value)}
            />
          </div>
          <Button onClick={handleTraining}>Start Training</Button>
          {trainingStatus && (
            <div className="mt-4 p-4 bg-muted rounded-lg">
              <p>{trainingStatus}</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}


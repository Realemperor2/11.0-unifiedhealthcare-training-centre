"use client"

import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"

export function AdvancedSettings() {
  const [nanoScale, setNanoScale] = useState(false)
  const [printSpeed, setPrintSpeed] = useState('100')
  const [customMaterial, setCustomMaterial] = useState('')

  const handleSaveSettings = () => {
    alert('Advanced settings saved!')
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Advanced Settings</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Label htmlFor="nano-scale">Nano-scale Precision</Label>
            <Switch
              id="nano-scale"
              checked={nanoScale}
              onCheckedChange={setNanoScale}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="print-speed">Print Speed (mm/s)</Label>
            <Input
              id="print-speed"
              type="number"
              value={printSpeed}
              onChange={(e) => setPrintSpeed(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="custom-material">Custom Material Composition</Label>
            <Input
              id="custom-material"
              value={customMaterial}
              onChange={(e) => setCustomMaterial(e.target.value)}
              placeholder="e.g., 70% PLA, 30% Carbon Fiber"
            />
          </div>
          <Button onClick={handleSaveSettings}>Save Advanced Settings</Button>
        </div>
      </CardContent>
    </Card>
  )
}


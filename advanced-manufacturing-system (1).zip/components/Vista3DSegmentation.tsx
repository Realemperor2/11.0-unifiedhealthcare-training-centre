"use client"

import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { apiRequest } from "@/utils/api"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Loader2 } from 'lucide-react'

export function Vista3DSegmentation() {
  const [imageUrl, setImageUrl] = useState('')
  const [classes, setClasses] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState('')
  const [error, setError] = useState<string | null>(null)

  const handleSegment = async () => {
    setLoading(true)
    setError(null)
    try {
      const response = await apiRequest('/vista3d', 'POST', {
        image_url: imageUrl,
        classes: classes.split(',').map(c => c.trim())
      })
      setResult(JSON.stringify(response, null, 2))
    } catch (error) {
      console.error('Error:', error)
      setError('An error occurred during image segmentation. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Vista 3D Segmentation</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Input
            placeholder="Enter image URL"
            value={imageUrl}
            onChange={(e) => setImageUrl(e.target.value)}
          />
          <Input
            placeholder="Enter classes (comma-separated)"
            value={classes}
            onChange={(e) => setClasses(e.target.value)}
          />
          <Button onClick={handleSegment} disabled={!imageUrl || !classes || loading}>
            {loading ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Segmenting...</> : 'Segment Image'}
          </Button>
          {error && (
            <Alert variant="destructive">
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          {result && (
            <div className="mt-4 p-4 bg-muted rounded-lg">
              <pre className="whitespace-pre-wrap">{result}</pre>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}


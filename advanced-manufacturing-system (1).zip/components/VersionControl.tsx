"use client"

import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

interface Commit {
  id: string;
  message: string;
  author: string;
  date: string;
}

export function VersionControl() {
  const [commits, setCommits] = useState<Commit[]>([])
  const [newCommit, setNewCommit] = useState({ message: '', author: '' })

  const addCommit = () => {
    if (newCommit.message && newCommit.author) {
      const commit: Commit = {
        id: Date.now().toString(),
        message: newCommit.message,
        author: newCommit.author,
        date: new Date().toLocaleString()
      }
      setCommits([commit, ...commits])
      setNewCommit({ message: '', author: '' })
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Version Control</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="commit-message">Commit Message</Label>
              <Input
                id="commit-message"
                value={newCommit.message}
                onChange={(e) => setNewCommit({ ...newCommit, message: e.target.value })}
                placeholder="Enter commit message"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="commit-author">Author</Label>
              <Input
                id="commit-author"
                value={newCommit.author}
                onChange={(e) => setNewCommit({ ...newCommit, author: e.target.value })}
                placeholder="Enter author name"
              />
            </div>
          </div>
          <Button onClick={addCommit}>Add Commit</Button>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Commit Message</TableHead>
                <TableHead>Author</TableHead>
                <TableHead>Date</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {commits.map((commit) => (
                <TableRow key={commit.id}>
                  <TableCell>{commit.message}</TableCell>
                  <TableCell>{commit.author}</TableCell>
                  <TableCell>{commit.date}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}


import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"

export default function TutorialGuide() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Tutorial Guide</CardTitle>
      </CardHeader>
      <CardContent>
        <p>Step-by-step tutorial guide goes here.</p>
      </CardContent>
    </Card>
  )
}


"use client"

import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Progress } from "@/components/ui/progress"

interface PrintJob {
  id: string
  name: string
  description: string
  status: 'queued' | 'printing' | 'completed'
  progress: number
}

export function PrintJobManager() {
  const [jobs, setJobs] = useState<PrintJob[]>([])
  const [newJob, setNewJob] = useState({ name: '', description: '' })

  const addJob = () => {
    if (newJob.name && newJob.description) {
      setJobs([...jobs, {
        id: Date.now().toString(),
        name: newJob.name,
        description: newJob.description,
        status: 'queued',
        progress: 0
      }])
      setNewJob({ name: '', description: '' })
    }
  }

  const startNextJob = () => {
    const updatedJobs = jobs.map((job, index) => {
      if (index === 0 && job.status === 'queued') {
        return { ...job, status: 'printing' }
      }
      return job
    })
    setJobs(updatedJobs)
  }

  const simulateProgress = () => {
    setJobs(jobs.map(job => {
      if (job.status === 'printing') {
        const newProgress = Math.min(job.progress + 10, 100)
        return {
          ...job,
          progress: newProgress,
          status: newProgress === 100 ? 'completed' : 'printing'
        }
      }
      return job
    }))
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Print Job Manager</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="job-name">Job Name</Label>
            <Input
              id="job-name"
              value={newJob.name}
              onChange={(e) => setNewJob({ ...newJob, name: e.target.value })}
              placeholder="Enter job name"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="job-description">Job Description</Label>
            <Textarea
              id="job-description"
              value={newJob.description}
              onChange={(e) => setNewJob({ ...newJob, description: e.target.value })}
              placeholder="Enter job description"
            />
          </div>
          <Button onClick={addJob}>Add Job</Button>
          <Button onClick={startNextJob}>Start Next Job</Button>
          <Button onClick={simulateProgress}>Simulate Progress</Button>
          
          {jobs.length > 0 && (
            <div className="mt-4 space-y-4">
              <h3 className="font-semibold">Print Queue:</h3>
              {jobs.map((job, index) => (
                <div key={job.id} className="p-4 bg-muted rounded-lg">
                  <h4 className="font-semibold">{job.name}</h4>
                  <p>{job.description}</p>
                  <p>Status: {job.status}</p>
                  {job.status === 'printing' && (
                    <Progress value={job.progress} className="mt-2" />
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}


"use client"

import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { apiRequest } from "@/utils/api"

interface AIDesignAssistantProps {
  components: any[]
  onSuggestion: (suggestion: any[]) => void
}

export function AIDesignAssistant({ components, onSuggestion }: AIDesignAssistantProps) {
  const [query, setQuery] = useState('')
  const [suggestion, setSuggestion] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleQuery = async () => {
    setIsLoading(true)
    setError(null)
    try {
      const response = await apiRequest('/api/openai', 'POST', {
        prompt: `Given the following production line components: ${JSON.stringify(components)}, ${query}`
      })

      setSuggestion(response.suggestion)

      // Parse the AI suggestion to create new components
      const newComponents = parseAISuggestion(response.suggestion)
      onSuggestion([...components, ...newComponents])
    } catch (err) {
      setError('Failed to get AI suggestion. Please try again.')
      console.error(err)
    } finally {
      setIsLoading(false)
    }
  }

  const parseAISuggestion = (suggestion: string) => {
    // This is a simplified parser. In a real application, you'd want a more robust parser.
    const newComponents = []
    const componentTypes = ['conveyor', 'robot', 'sensor', 'workstation', 'storage', 'qc']
    
    componentTypes.forEach(type => {
      const regex = new RegExp(`Add a ${type}`, 'gi')
      const matches = suggestion.match(regex)
      if (matches) {
        for (let i = 0; i < matches.length; i++) {
          newComponents.push({
            id: `${type}-${components.length + i}`,
            type: type,
            position: [components.length * 2 + i * 2, 0, 0],
            rotation: [0, 0, 0],
            settings: {}
          })
        }
      }
    })

    return newComponents
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>AI Design Assistant</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Textarea
            placeholder="Ask for design suggestions..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          <Button onClick={handleQuery} disabled={isLoading}>
            {isLoading ? 'Getting Suggestion...' : 'Get AI Suggestion'}
          </Button>
          {error && (
            <div className="text-red-500">{error}</div>
          )}
          {suggestion && (
            <div className="mt-4 p-4 bg-muted rounded-lg">
              <p className="whitespace-pre-line">{suggestion}</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}


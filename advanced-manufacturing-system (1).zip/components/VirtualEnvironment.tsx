"use client"

import { useState, useRef, useEffect } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { OrbitControls, Box, Cylinder, Html } from '@react-three/drei'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

function SimulatedProductionLine() {
  const conveyorRef = useRef<THREE.Mesh>(null)
  const robotRef = useRef<THREE.Group>(null)
  const [productPosition, setProductPosition] = useState(0)

  useFrame((state) => {
    if (conveyorRef.current) {
      conveyorRef.current.rotation.x += 0.01
    }
    if (robotRef.current) {
      robotRef.current.rotation.y = Math.sin(state.clock.elapsedTime) * 0.5
    }
    setProductPosition((prev) => (prev + 0.01) % 2)
  })

  return (
    <>
      <Box args={[2, 0.1, 0.5]} position={[0, 0, 0]} ref={conveyorRef}>
        <meshStandardMaterial color="gray" />
      </Box>
      <group position={[1, 0.5, 0]} ref={robotRef}>
        <Cylinder args={[0.1, 0.1, 0.5, 32]} position={[0, 0, 0]}>
          <meshStandardMaterial color="blue" />
        </Cylinder>
        <Box args={[0.4, 0.1, 0.1]} position={[0, 0.25, 0]}>
          <meshStandardMaterial color="red" />
        </Box>
      </group>
      <Cylinder args={[0.1, 0.1, 0.2, 32]} position={[2, 0.1, 0]}>
        <meshStandardMaterial color="green" />
      </Cylinder>
      <Box args={[0.2, 0.2, 0.2]} position={[-1 + productPosition, 0.15, 0]}>
        <meshStandardMaterial color="yellow" />
      </Box>
    </>
  )
}

export default function VirtualEnvironment() {
  const [isRunning, setIsRunning] = useState(false)

  return (
    <Card className="col-span-2">
      <CardHeader>
        <CardTitle>Virtual Environment</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="w-full h-[400px] bg-muted rounded-lg overflow-hidden">
            <Canvas camera={{ position: [0, 2, 5] }}>
              <ambientLight intensity={0.5} />
              <pointLight position={[10, 10, 10]} />
              {isRunning && <SimulatedProductionLine />}
              <OrbitControls />
              <Html position={[0, 1, 0]}>
                <div className="bg-white p-2 rounded">
                  Status: {isRunning ? 'Running' : 'Stopped'}
                </div>
              </Html>
            </Canvas>
          </div>
          <Button onClick={() => setIsRunning(!isRunning)}>
            {isRunning ? 'Stop Simulation' : 'Start Simulation'}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}


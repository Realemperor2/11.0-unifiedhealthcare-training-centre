import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export function ClaimProcessing() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Claim Processing</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Input placeholder="Enter claim number..." />
          <div className="grid grid-cols-2 gap-4">
            <Button>Process Claim</Button>
            <Button variant="outline">View Claim History</Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}


"use client"

import { useState, useEffect } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

interface HealthRecord {
  id: string
  name: string
  age: number
  condition: string
}

export function HealthRecordSystem() {
  const [records, setRecords] = useState<HealthRecord[]>([])
  const [searchTerm, setSearchTerm] = useState('')
  const [newRecord, setNewRecord] = useState<HealthRecord>({ id: '', name: '', age: 0, condition: '' })

  useEffect(() => {
    const savedRecords = localStorage.getItem('healthRecords')
    if (savedRecords) {
      setRecords(JSON.parse(savedRecords))
    }
  }, [])

  const addRecord = () => {
    const recordToAdd = { ...newRecord, id: Date.now().toString() }
    const updatedRecords = [...records, recordToAdd]
    setRecords(updatedRecords)
    localStorage.setItem('healthRecords', JSON.stringify(updatedRecords))
    setNewRecord({ id: '', name: '', age: 0, condition: '' })
  }

  const filteredRecords = records.filter(record => 
    record.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    record.condition.toLowerCase().includes(searchTerm.toLowerCase())
  )

  return (
    <Card>
      <CardHeader>
        <CardTitle>Health Record System</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Input 
            placeholder="Search patient records..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <div className="grid grid-cols-2 gap-4">
            <Input 
              placeholder="Name" 
              value={newRecord.name}
              onChange={(e) => setNewRecord({ ...newRecord, name: e.target.value })}
            />
            <Input 
              type="number" 
              placeholder="Age"
              value={newRecord.age || ''}
              onChange={(e) => setNewRecord({ ...newRecord, age: parseInt(e.target.value) || 0 })}
            />
            <Input 
              placeholder="Condition"
              value={newRecord.condition}
              onChange={(e) => setNewRecord({ ...newRecord, condition: e.target.value })}
            />
            <Button onClick={addRecord}>Add Record</Button>
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Age</TableHead>
                <TableHead>Condition</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredRecords.map((record) => (
                <TableRow key={record.id}>
                  <TableCell>{record.name}</TableCell>
                  <TableCell>{record.age}</TableCell>
                  <TableCell>{record.condition}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}


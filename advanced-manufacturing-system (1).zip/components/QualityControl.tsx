"use client"

import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export default function QualityControl() {
  const [productId, setProductId] = useState('')
  const [qualityReport, setQualityReport] = useState('')

  const handleInspect = () => {
    // Simulate quality inspection
    setQualityReport(`Quality report for product ${productId}: Passed all quality checks.`)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Quality Control</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Input
            placeholder="Enter product ID"
            value={productId}
            onChange={(e) => setProductId(e.target.value)}
          />
          <Button onClick={handleInspect} disabled={!productId}>
            Inspect Product
          </Button>
          {qualityReport && (
            <div className="mt-4 p-4 bg-muted rounded-lg">
              <p>{qualityReport}</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}


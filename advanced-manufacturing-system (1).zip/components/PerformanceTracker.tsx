"use client"

import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'

interface PerformanceData {
  name: string;
  score: number;
}

export function PerformanceTracker() {
  const [performanceData, setPerformanceData] = useState<PerformanceData[]>([])
  const [newEntry, setNewEntry] = useState({ name: '', score: '' })

  const addPerformanceEntry = () => {
    if (newEntry.name && newEntry.score) {
      setPerformanceData([...performanceData, { name: newEntry.name, score: parseInt(newEntry.score) }])
      setNewEntry({ name: '', score: '' })
    }
  }

  return (
    <Card className="col-span-2">
      <CardHeader>
        <CardTitle>Performance Tracker</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="trainee-name">Trainee Name</Label>
              <Input
                id="trainee-name"
                value={newEntry.name}
                onChange={(e) => setNewEntry({ ...newEntry, name: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="performance-score">Performance Score</Label>
              <Input
                id="performance-score"
                type="number"
                value={newEntry.score}
                onChange={(e) => setNewEntry({ ...newEntry, score: e.target.value })}
              />
            </div>
            <div className="flex items-end">
              <Button onClick={addPerformanceEntry}>Add Entry</Button>
            </div>
          </div>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={performanceData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="score" fill="#8884d8" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}


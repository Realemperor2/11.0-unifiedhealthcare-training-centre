"use client"

import { useState, useRef } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { OrbitControls, Sphere, Cylinder } from '@react-three/drei'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import * as THREE from 'three'

type MaterialType = 'PLA' | 'ABS' | 'PETG' | 'Nylon' | 'Resin'

interface Material {
  type: MaterialType
  color: string
  quantity: number
}

function MaterialVisualization({ materials }: { materials: Material[] }) {
  const groupRef = useRef<THREE.Group>(null)

  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y += 0.01
    }
  })

  return (
    <group ref={groupRef}>
      {materials.map((material, index) => (
        <Sphere
          key={index}
          args={[0.2 * Math.pow(material.quantity, 1/3), 32, 32]}
          position={[index * 0.5 - (materials.length - 1) * 0.25, 0, 0]}
        >
          <meshStandardMaterial color={material.color} />
        </Sphere>
      ))}
      <Cylinder args={[0.5, 0.5, 0.1, 32]} position={[0, -0.5, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <meshStandardMaterial color="gray" />
      </Cylinder>
    </group>
  )
}

export function RawMaterialsPreprocessor() {
  const [materials, setMaterials] = useState<Material[]>([])
  const [currentMaterial, setCurrentMaterial] = useState<Material>({ type: 'PLA', color: '#FFFFFF', quantity: 1 })
  const [mixture, setMixture] = useState<string>('')

  const addMaterial = () => {
    setMaterials([...materials, currentMaterial])
    setCurrentMaterial({ type: 'PLA', color: '#FFFFFF', quantity: 1 })
  }

  const processMaterials = () => {
    const totalQuantity = materials.reduce((sum, material) => sum + material.quantity, 0)
    const mixtureDescription = materials.map(material => 
      `${(material.quantity / totalQuantity * 100).toFixed(2)}% ${material.type}`
    ).join(', ')
    setMixture(`Processed mixture: ${mixtureDescription}`)
  }

  return (
    <Card className="col-span-2">
      <CardHeader>
        <CardTitle>Raw Materials Preprocessor</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="material-type">Material Type</Label>
              <Select
                value={currentMaterial.type}
                onValueChange={(value: MaterialType) => setCurrentMaterial({ ...currentMaterial, type: value })}
              >
                <SelectTrigger id="material-type">
                  <SelectValue placeholder="Select material type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="PLA">PLA</SelectItem>
                  <SelectItem value="ABS">ABS</SelectItem>
                  <SelectItem value="PETG">PETG</SelectItem>
                  <SelectItem value="Nylon">Nylon</SelectItem>
                  <SelectItem value="Resin">Resin</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="material-color">Color</Label>
              <Input
                id="material-color"
                type="color"
                value={currentMaterial.color}
                onChange={(e) => setCurrentMaterial({ ...currentMaterial, color: e.target.value })}
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="material-quantity">Quantity (kg)</Label>
            <Input
              id="material-quantity"
              type="number"
              min="0.1"
              step="0.1"
              value={currentMaterial.quantity}
              onChange={(e) => setCurrentMaterial({ ...currentMaterial, quantity: parseFloat(e.target.value) })}
            />
          </div>
          <Button onClick={addMaterial}>Add Material</Button>
          <div className="h-64 w-full bg-muted rounded-lg overflow-hidden">
            <Canvas camera={{ position: [0, 0, 5] }}>
              <ambientLight intensity={0.5} />
              <pointLight position={[10, 10, 10]} />
              <MaterialVisualization materials={materials} />
              <OrbitControls />
            </Canvas>
          </div>
          <Button onClick={processMaterials}>Process Materials</Button>
          {mixture && (
            <div className="mt-4 p-4 bg-muted rounded-lg">
              <p>{mixture}</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}


"use client"

import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { apiRequest } from "@/utils/api"

export function AppGenerator() {
  const [prompt, setPrompt] = useState('')
  const [generatedApp, setGeneratedApp] = useState('')
  const [generationStatus, setGenerationStatus] = useState('')

  const handleAppGeneration = async () => {
    setGenerationStatus('Generating app...')
    try {
      const response = await apiRequest('/api/generate-app', 'POST', { prompt })
      setGeneratedApp(response.appCode)
      setGenerationStatus('App generated successfully!')
    } catch (error) {
      setGenerationStatus('App generation failed. Please try again.')
      console.error('App generation error:', error)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>App Generator</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Textarea
            placeholder="Describe the app you want to generate..."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            rows={4}
          />
          <Button onClick={handleAppGeneration}>Generate App</Button>
          {generationStatus && (
            <div className="mt-4 p-4 bg-muted rounded-lg">
              <p>{generationStatus}</p>
            </div>
          )}
          {generatedApp && (
            <div className="mt-4 p-4 bg-muted rounded-lg">
              <h3 className="text-lg font-semibold mb-2">Generated App Code:</h3>
              <pre className="whitespace-pre-wrap">{generatedApp}</pre>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}


"use client"

import { useState, useEffect } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'

interface HealthMetric {
  timestamp: string;
  heartRate: number;
  bloodPressure: number;
  oxygenSaturation: number;
}

export function HealthMetricsMonitor() {
  const [metrics, setMetrics] = useState<HealthMetric[]>([])

  useEffect(() => {
    const interval = setInterval(() => {
      const newMetric: HealthMetric = {
        timestamp: new Date().toLocaleTimeString(),
        heartRate: Math.floor(Math.random() * (100 - 60) + 60),
        bloodPressure: Math.floor(Math.random() * (140 - 110) + 110),
        oxygenSaturation: Math.floor(Math.random() * (100 - 95) + 95),
      }
      setMetrics(prevMetrics => [...prevMetrics.slice(-19), newMetric])
    }, 1000)

    return () => clearInterval(interval)
  }, [])

  return (
    <Card className="col-span-2">
      <CardHeader>
        <CardTitle>Real-time Health Metrics Monitor</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[400px]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={metrics}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="timestamp" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="heartRate" stroke="#8884d8" name="Heart Rate" />
              <Line type="monotone" dataKey="bloodPressure" stroke="#82ca9d" name="Blood Pressure" />
              <Line type="monotone" dataKey="oxygenSaturation" stroke="#ffc658" name="Oxygen Saturation" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}


"use client"

import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { apiRequest } from "@/utils/api"

export function AgentCreation() {
  const [agentName, setAgentName] = useState('')
  const [agentDescription, setAgentDescription] = useState('')
  const [agentCapabilities, setAgentCapabilities] = useState('')
  const [creationStatus, setCreationStatus] = useState('')

  const handleAgentCreation = async () => {
    setCreationStatus('Creating agent...')
    try {
      const response = await apiRequest('/api/create-agent', 'POST', {
        name: agentName,
        description: agentDescription,
        capabilities: agentCapabilities.split(',').map(cap => cap.trim())
      })
      setCreationStatus(`Agent created successfully. Agent ID: ${response.agentId}`)
    } catch (error) {
      setCreationStatus('Agent creation failed. Please check your inputs and try again.')
      console.error('Agent creation error:', error)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Agent Creation</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="agent-name">Agent Name</Label>
            <Input
              id="agent-name"
              placeholder="Enter agent name"
              value={agentName}
              onChange={(e) => setAgentName(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="agent-description">Agent Description</Label>
            <Textarea
              id="agent-description"
              placeholder="Describe the agent's purpose"
              value={agentDescription}
              onChange={(e) => setAgentDescription(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="agent-capabilities">Agent Capabilities (comma-separated)</Label>
            <Input
              id="agent-capabilities"
              placeholder="e.g., text analysis, image recognition"
              value={agentCapabilities}
              onChange={(e) => setAgentCapabilities(e.target.value)}
            />
          </div>
          <Button onClick={handleAgentCreation}>Create Agent</Button>
          {creationStatus && (
            <div className="mt-4 p-4 bg-muted rounded-lg">
              <p>{creationStatus}</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}


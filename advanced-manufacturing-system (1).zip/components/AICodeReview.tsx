"use client"

import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { apiRequest } from "@/utils/api"
import { Loader2 } from 'lucide-react'

export function AICodeReview() {
  const [code, setCode] = useState('')
  const [review, setReview] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleReview = async () => {
    setIsLoading(true)
    setError(null)
    try {
      const response = await apiRequest('/api/code-review', 'POST', { code })
      setReview(response.review)
    } catch (err) {
      setError('Failed to get AI code review. Please try again.')
      console.error(err)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>AI Code Review</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Textarea
            placeholder="Paste your code here..."
            value={code}
            onChange={(e) => setCode(e.target.value)}
            rows={10}
          />
          <Button onClick={handleReview} disabled={isLoading || !code}>
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Reviewing...
              </>
            ) : (
              'Review Code'
            )}
          </Button>
          {error && (
            <div className="text-red-500">{error}</div>
          )}
          {review && (
            <div className="mt-4 p-4 bg-muted rounded-lg">
              <pre className="whitespace-pre-wrap">{review}</pre>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}


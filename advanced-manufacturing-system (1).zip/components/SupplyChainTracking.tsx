import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export function SupplyChainTracking() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Supply Chain Tracking</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Input placeholder="Enter order number..." />
          <div className="grid grid-cols-2 gap-4">
            <Button>Track Order</Button>
            <Button variant="outline">View Suppliers</Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}


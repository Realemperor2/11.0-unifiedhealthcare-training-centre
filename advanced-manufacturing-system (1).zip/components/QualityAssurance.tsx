"use client"

import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { apiRequest } from "@/utils/api"

export function QualityAssurance() {
  const [batchNumber, setBatchNumber] = useState('')
  const [qualityReport, setQualityReport] = useState('')

  const handleQualityCheck = async () => {
    try {
      const data = await apiRequest('/generate_text', 'POST', { prompt: `Generate a quality report for raw material batch ${batchNumber}` })
      setQualityReport(data.text)
    } catch (error) {
      console.error('Error:', error)
      setQualityReport('An error occurred while generating the quality report.')
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Quality Assurance</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Input
            placeholder="Enter batch number..."
            value={batchNumber}
            onChange={(e) => setBatchNumber(e.target.value)}
          />
          <Button onClick={handleQualityCheck}>Check Quality</Button>
          {qualityReport && (
            <div className="mt-4 p-4 bg-muted rounded-lg">
              <p>{qualityReport}</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}


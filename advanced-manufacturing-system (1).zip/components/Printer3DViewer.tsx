"use client"

import { useState, useRef } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { OrbitControls, Box, Cylinder, Html } from '@react-three/drei'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import * as THREE from 'three'

function PrinterModel() {
  const printerRef = useRef<THREE.Group>(null)
  const [hovered, setHovered] = useState(false)

  useFrame((state) => {
    if (printerRef.current) {
      printerRef.current.rotation.y += 0.005
    }
  })

  return (
    <group
      ref={printerRef}
      onPointerOver={() => setHovered(true)}
      onPointerOut={() => setHovered(false)}
    >
      {/* Printer Frame */}
      <Box args={[2, 3, 2]} position={[0, 1.5, 0]}>
        <meshStandardMaterial color={hovered ? "hotpink" : "gray"} />
      </Box>
      
      {/* Print Bed */}
      <Box args={[1.8, 0.1, 1.8]} position={[0, 0.05, 0]}>
        <meshStandardMaterial color="darkgray" />
      </Box>
      
      {/* Print Heads */}
      {[...Array(6)].map((_, i) => (
        <Cylinder
          key={i}
          args={[0.1, 0.1, 0.3, 32]}
          position={[
            Math.cos(i * Math.PI / 3) * 0.5,
            2.8,
            Math.sin(i * Math.PI / 3) * 0.5
          ]}
        >
          <meshStandardMaterial color="blue" />
        </Cylinder>
      ))}
      
      <Html position={[0, 3.5, 0]}>
        <div className="bg-white p-2 rounded text-center">
          <p className="font-bold">3D Printer 3.0</p>
          <p>60+ print heads</p>
          <p>Nanoscale precision</p>
        </div>
      </Html>
    </group>
  )
}

export function Printer3DViewer() {
  const [isRunning, setIsRunning] = useState(false)

  return (
    <Card className="col-span-2">
      <CardHeader>
        <CardTitle>3D Printer 3.0 Viewer</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="h-[400px] w-full bg-muted rounded-lg overflow-hidden">
            <Canvas camera={{ position: [0, 2, 5] }}>
              <ambientLight intensity={0.5} />
              <pointLight position={[10, 10, 10]} />
              <PrinterModel />
              <OrbitControls />
            </Canvas>
          </div>
          <Button onClick={() => setIsRunning(!isRunning)}>
            {isRunning ? 'Stop Printer' : 'Start Printer'}
          </Button>
          {isRunning && (
            <div className="mt-4 p-4 bg-muted rounded-lg">
              <p>Printer is running. Current status: Operational</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}


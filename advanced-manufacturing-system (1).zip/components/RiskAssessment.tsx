"use client"

import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function RiskAssessment() {
  const [age, setAge] = useState('')
  const [healthCondition, setHealthCondition] = useState('')
  const [occupation, setOccupation] = useState('')
  const [riskScore, setRiskScore] = useState<number | null>(null)

  const calculateRisk = () => {
    let score = 0
    
    // Age factor
    const ageNum = parseInt(age)
    if (ageNum < 30) score += 10
    else if (ageNum < 50) score += 20
    else if (ageNum < 70) score += 30
    else score += 40

    // Health condition factor
    if (healthCondition === 'excellent') score += 10
    else if (healthCondition === 'good') score += 20
    else if (healthCondition === 'fair') score += 30
    else if (healthCondition === 'poor') score += 40

    // Occupation factor
    if (occupation === 'low-risk') score += 10
    else if (occupation === 'medium-risk') score += 20
    else if (occupation === 'high-risk') score += 30

    setRiskScore(score)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Risk Assessment</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="age">Age</Label>
            <Input
              id="age"
              type="number"
              value={age}
              onChange={(e) => setAge(e.target.value)}
              placeholder="Enter age"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="health-condition">Health Condition</Label>
            <Select onValueChange={setHealthCondition}>
              <SelectTrigger id="health-condition">
                <SelectValue placeholder="Select health condition" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="excellent">Excellent</SelectItem>
                <SelectItem value="good">Good</SelectItem>
                <SelectItem value="fair">Fair</SelectItem>
                <SelectItem value="poor">Poor</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="occupation">Occupation Risk Level</Label>
            <Select onValueChange={setOccupation}>
              <SelectTrigger id="occupation">
                <SelectValue placeholder="Select occupation risk level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low-risk">Low Risk</SelectItem>
                <SelectItem value="medium-risk">Medium Risk</SelectItem>
                <SelectItem value="high-risk">High Risk</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button onClick={calculateRisk}>Calculate Risk</Button>
          {riskScore !== null && (
            <div className="mt-4 p-4 bg-muted rounded-lg">
              <p>Risk Score: {riskScore}</p>
              <p>Risk Level: {riskScore < 40 ? 'Low' : riskScore < 70 ? 'Medium' : 'High'}</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}


"use client"

import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export default function PrinterControl() {
  const [printJob, setPrintJob] = useState('')
  const [isPrinting, setIsPrinting] = useState(false)

  const handlePrint = () => {
    setIsPrinting(true)
    // Simulate printing process
    setTimeout(() => setIsPrinting(false), 3000)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>3D Printer Control</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="print-job">Print Job</Label>
            <Input
              id="print-job"
              placeholder="Enter print job name"
              value={printJob}
              onChange={(e) => setPrintJob(e.target.value)}
            />
          </div>
          <Button onClick={handlePrint} disabled={!printJob || isPrinting}>
            {isPrinting ? 'Printing...' : 'Start Print'}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}


"use client"

import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { apiRequest } from "@/utils/api"

export function CodeGenerator() {
  const [prompt, setPrompt] = useState('')
  const [language, setLanguage] = useState('')
  const [generatedCode, setGeneratedCode] = useState('')
  const [sentiment, setSentiment] = useState<number | null>(null)
  const [loading, setLoading] = useState(false)

const generateCode = async () => {
  setLoading(true);
  try {
    // Generate code
    const codeData = await apiRequest('/generate_text', 'POST', { prompt: `Generate ${language} code for: ${prompt}` });
    setGeneratedCode(codeData.text);

    // Analyze sentiment of comments
    const comments = codeData.text.match(/\/\/.+/g)?.join('\n') || '';
    const sentimentData = await apiRequest('/sentiment_analysis', 'POST', { prompt: comments });
    setSentiment(sentimentData.sentiment);
  } catch (error) {
    console.error('Error:', error);
    setGeneratedCode('An error occurred during code generation.');
    setSentiment(null);
  } finally {
    setLoading(false);
  }
};

  return (
    <Card>
      <CardHeader>
        <CardTitle>AI Code Generator</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Enter your code requirements..."
            className="min-h-[100px]"
          />
          <Select onValueChange={setLanguage}>
            <SelectTrigger>
              <SelectValue placeholder="Select programming language" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="javascript">JavaScript</SelectItem>
              <SelectItem value="python">Python</SelectItem>
              <SelectItem value="java">Java</SelectItem>
              <SelectItem value="csharp">C#</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={generateCode} disabled={!prompt || !language || loading} className="w-full">
            {loading ? 'Generating...' : 'Generate Code'}
          </Button>
          {generatedCode && (
            <div className="p-4 bg-muted rounded-lg">
              <pre className="text-sm whitespace-pre-wrap">{generatedCode}</pre>
            </div>
          )}
          {sentiment !== null && (
            <div className="mt-4">
              <p>Comment Sentiment: {sentiment > 0.5 ? 'Positive' : 'Negative'} ({(sentiment * 100).toFixed(2)}%)</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}


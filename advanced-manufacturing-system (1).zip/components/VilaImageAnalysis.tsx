"use client"

import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { apiRequest } from "@/utils/api"

export function VilaImageAnalysis() {
  const [imageUrl, setImageUrl] = useState('')
  const [query, setQuery] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState('')

  const handleAnalyze = async () => {
    setLoading(true)
    try {
      const response = await apiRequest('/vila', 'POST', { image_url: imageUrl, query })
      setResult(response.choices[0].message.content)
    } catch (error) {
      console.error('Error:', error)
      setResult('An error occurred during image analysis.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>VILA Image Analysis</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Input
            placeholder="Enter image URL"
            value={imageUrl}
            onChange={(e) => setImageUrl(e.target.value)}
          />
          <Textarea
            placeholder="Enter your query about the image..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            rows={3}
          />
          <Button onClick={handleAnalyze} disabled={!imageUrl || !query || loading}>
            {loading ? 'Analyzing...' : 'Analyze Image'}
          </Button>
          {result && (
            <div className="mt-4 p-4 bg-muted rounded-lg">
              <p>{result}</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}


"use client"

import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export function PaymentDashboard() {
  const [balance, setBalance] = useState(1000)

  return (
    <Card>
      <CardHeader>
        <CardTitle>Payment Dashboard</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="text-2xl font-bold">Current Balance: ${balance.toFixed(2)}</div>
          <div className="grid grid-cols-2 gap-4">
            <Button onClick={() => setBalance(prev => prev + 100)}>Add Funds</Button>
            <Button variant="outline" onClick={() => setBalance(prev => Math.max(0, prev - 100))}>Withdraw</Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}


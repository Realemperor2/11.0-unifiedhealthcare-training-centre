"use client"

import { useState, useEffect, useRef } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Canvas } from '@react-three/fiber'
import { OrbitControls, Sphere } from '@react-three/drei'

function ScanVisualizer({ data }: { data: number[] }) {
  return (
    <Canvas>
      <ambientLight intensity={0.5} />
      <pointLight position={[10, 10, 10]} />
      {data.map((value, index) => (
        <Sphere key={index} position={[index - 2, value - 0.5, 0]} args={[0.1, 16, 16]}>
          <meshStandardMaterial color={`hsl(${value * 360}, 100%, 50%)`} />
        </Sphere>
      ))}
      <OrbitControls />
    </Canvas>
  )
}

export function PhoneSensorScan() {
  const [isScanning, setIsScanning] = useState(false)
  const [scanData, setScanData] = useState<number[]>([])
  const [analysis, setAnalysis] = useState('')
  const scanInterval = useRef<NodeJS.Timeout | null>(null)

  useEffect(() => {
    return () => {
      if (scanInterval.current) {
        clearInterval(scanInterval.current)
      }
    }
  }, [])

  const startScan = () => {
    setIsScanning(true)
    setScanData([])
    setAnalysis('')

    scanInterval.current = setInterval(() => {
      setScanData(prev => {
        if (prev.length >= 5) {
          clearInterval(scanInterval.current!)
          setIsScanning(false)
          analyzeData(prev)
          return prev
        }
        return [...prev, Math.random()]
      })
    }, 1000)
  }

  const analyzeData = (data: number[]) => {
    // Simulate AI analysis
    setTimeout(() => {
      setAnalysis(`Based on the scan data, we've detected the following:
        - Potential anomaly in region ${Math.floor(Math.random() * 5) + 1}
        - Overall health index: ${(Math.random() * 100).toFixed(2)}
        - Recommended follow-up: ${Math.random() > 0.5 ? 'Further examination needed' : 'No immediate action required'}`)
    }, 2000)
  }

  return (
    <Card className="col-span-2">
      <CardHeader>
        <CardTitle>Phone Sensor Medical Scan</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Button onClick={startScan} disabled={isScanning}>
            {isScanning ? 'Scanning...' : 'Start Scan'}
          </Button>
          {scanData.length > 0 && (
            <div className="w-full h-[300px] bg-muted rounded-lg overflow-hidden">
              <ScanVisualizer data={scanData} />
            </div>
          )}
          {analysis && (
            <div className="mt-4 p-4 bg-muted rounded-lg">
              <h3 className="font-semibold mb-2">AI Analysis:</h3>
              <p className="whitespace-pre-line">{analysis}</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}


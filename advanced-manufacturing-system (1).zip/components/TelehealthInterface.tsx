"use client"

import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export function TelehealthInterface() {
  const [isCallActive, setIsCallActive] = useState(false)
  const [patientName, setPatientName] = useState('')
  const [messages, setMessages] = useState<{ sender: string; text: string }[]>([])
  const [newMessage, setNewMessage] = useState('')

  const startCall = () => {
    if (patientName) {
      setIsCallActive(true)
      setMessages([{ sender: 'System', text: `Call started with ${patientName}` }])
    }
  }

  const endCall = () => {
    setIsCallActive(false)
    setPatientName('')
    setMessages([])
  }

  const sendMessage = () => {
    if (newMessage.trim()) {
      setMessages([...messages, { sender: 'You', text: newMessage }])
      setNewMessage('')
      // Simulate doctor's response
      setTimeout(() => {
        setMessages(prev => [...prev, { sender: 'Doctor', text: 'Thank you for your message. How can I help you today?' }])
      }, 1000)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Telehealth Interface</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {!isCallActive ? (
            <>
              <div className="space-y-2">
                <Label htmlFor="patient-name">Patient Name</Label>
                <Input
                  id="patient-name"
                  value={patientName}
                  onChange={(e) => setPatientName(e.target.value)}
                  placeholder="Enter patient name"
                />
              </div>
              <Button onClick={startCall} disabled={!patientName}>Start Call</Button>
            </>
          ) : (
            <>
              <div className="aspect-video bg-muted rounded-lg flex items-center justify-center">
                Active Call with {patientName}
              </div>
              <div className="mt-4 space-y-4">
                <div className="h-60 overflow-y-auto bg-gray-100 p-4 rounded">
                  {messages.map((message, index) => (
                    <div key={index} className={`mb-2 ${message.sender === 'You' ? 'text-right' : 'text-left'}`}>
                      <span className="font-bold">{message.sender}: </span>
                      {message.text}
                    </div>
                  ))}
                </div>
                <div className="flex space-x-2">
                  <Input
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder="Type your message..."
                    onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                  />
                  <Button onClick={sendMessage}>Send</Button>
                </div>
              </div>
              <Button onClick={endCall} variant="destructive">End Call</Button>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  )
}


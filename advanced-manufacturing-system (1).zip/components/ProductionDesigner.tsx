"use client"

import { useState } from 'react'
import { Canvas } from '@react-three/fiber'
import { OrbitControls, Box, Sphere, Cylinder } from '@react-three/drei'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

function Scene() {
  return (
    <>
      <ambientLight intensity={0.5} />
      <pointLight position={[10, 10, 10]} />
      <Box position={[-1.2, 0, 0]}>
        <meshStandardMaterial color="orange" />
      </Box>
      <Sphere position={[1.2, 0, 0]}>
        <meshStandardMaterial color="hotpink" />
      </Sphere>
      <Cylinder position={[0, 1.2, 0]}>
        <meshStandardMaterial color="lightblue" />
      </Cylinder>
      <OrbitControls />
    </>
  )
}

export default function ProductionDesigner() {
  const [selectedComponent, setSelectedComponent] = useState('')

  return (
    <Card className="col-span-2">
      <CardHeader>
        <CardTitle>Production Line Designer</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex space-x-4">
            <Select onValueChange={setSelectedComponent}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select component" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="conveyor">Conveyor Belt</SelectItem>
                <SelectItem value="robot">Robotic Arm</SelectItem>
                <SelectItem value="sensor">Sensor</SelectItem>
              </SelectContent>
            </Select>
            <Button disabled={!selectedComponent}>Add Component</Button>
          </div>
          <div className="w-full h-[400px] bg-muted rounded-lg overflow-hidden">
            <Canvas>
              <Scene />
            </Canvas>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}


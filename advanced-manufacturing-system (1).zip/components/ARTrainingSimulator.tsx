"use client"

import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Canvas } from '@react-three/fiber'
import { OrbitControls, Box, Text } from '@react-three/drei'

function ARScene({ scenario }: { scenario: string }) {
  return (
    <>
      <ambientLight intensity={0.5} />
      <pointLight position={[10, 10, 10]} />
      <Box args={[1, 1, 1]} position={[0, 0, 0]}>
        <meshStandardMaterial color="blue" />
      </Box>
      <Text position={[0, 1.5, 0]} fontSize={0.2} color="white">
        {scenario}
      </Text>
      <OrbitControls />
    </>
  )
}

export function ARTrainingSimulator() {
  const [scenario, setScenario] = useState('')
  const [isSimulating, setIsSimulating] = useState(false)

  const startSimulation = () => {
    setIsSimulating(true)
  }

  const stopSimulation = () => {
    setIsSimulating(false)
  }

  return (
    <Card className="col-span-2">
      <CardHeader>
        <CardTitle>AR Training Simulator</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Select onValueChange={setScenario}>
            <SelectTrigger>
              <SelectValue placeholder="Select training scenario" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="machine-operation">Machine Operation</SelectItem>
              <SelectItem value="safety-procedures">Safety Procedures</SelectItem>
              <SelectItem value="quality-control">Quality Control</SelectItem>
            </SelectContent>
          </Select>
          <div className="h-[400px] bg-muted rounded-lg overflow-hidden">
            <Canvas>
              <ARScene scenario={scenario} />
            </Canvas>
          </div>
          <div className="flex justify-between">
            <Button onClick={startSimulation} disabled={!scenario || isSimulating}>
              Start Simulation
            </Button>
            <Button onClick={stopSimulation} disabled={!isSimulating}>
              Stop Simulation
            </Button>
          </div>
          {isSimulating && (
            <div className="mt-4 p-4 bg-muted rounded-lg">
              <p>Simulating {scenario} scenario. Follow the AR instructions on your device.</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}


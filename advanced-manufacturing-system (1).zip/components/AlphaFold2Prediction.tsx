"use client"

import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { apiRequest } from "@/utils/api"

export function AlphaFold2Prediction() {
  const [sequences, setSequences] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState('')

  const handlePredict = async () => {
    setLoading(true)
    try {
      const response = await apiRequest('/alphafold2', 'POST', { sequences: sequences.split('\n') })
      setResult(JSON.stringify(response, null, 2))
    } catch (error) {
      console.error('Error:', error)
      setResult('An error occurred during protein structure prediction.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>AlphaFold2 Protein Structure Prediction</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Textarea
            placeholder="Enter protein sequences (one per line)..."
            value={sequences}
            onChange={(e) => setSequences(e.target.value)}
            rows={6}
          />
          <Button onClick={handlePredict} disabled={!sequences || loading}>
            {loading ? 'Predicting...' : 'Predict Structure'}
          </Button>
          {result && (
            <div className="mt-4 p-4 bg-muted rounded-lg">
              <pre className="whitespace-pre-wrap">{result}</pre>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}


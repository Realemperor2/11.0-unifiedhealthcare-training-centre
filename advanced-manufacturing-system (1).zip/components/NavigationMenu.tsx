"use client"

import Link from 'next/link'
import { usePathname } from 'next/navigation'

const navItems = [
  { href: '/', label: 'Dashboard' },
  { href: '/healthcare', label: 'Healthcare' },
  { href: '/training', label: 'Training' },
  { href: '/insurance', label: 'Insurance' },
  { href: '/production', label: 'Production' },
  { href: '/software', label: 'Software' },
  { href: '/raw-materials', label: 'Raw Materials' },
]

export function NavigationMenu() {
  const pathname = usePathname()

  return (
    <nav className="w-64 bg-white shadow-lg">
      <div className="p-4">
        <h1 className="text-2xl font-bold text-gray-800">AMS</h1>
      </div>
      <ul className="space-y-2 p-4">
        {navItems.map((item) => (
          <li key={item.href}>
            <Link
              href={item.href}
              className={`block px-4 py-2 rounded-md ${
                pathname === item.href
                  ? 'bg-blue-500 text-white'
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              {item.label}
            </Link>
          </li>
        ))}
      </ul>
    </nav>
  )
}


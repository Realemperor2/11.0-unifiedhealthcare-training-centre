"use client"

import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"

export function AIControlPanel() {
  const [query, setQuery] = useState('')
  const [aiResponse, setAiResponse] = useState('')

  const handleAIQuery = () => {
    // Simulated AI response
    setAiResponse(`AI Analysis for "${query}":
1. Optimized print settings applied
2. Material usage efficiency increased by 15%
3. Estimated print time reduced by 22 minutes
4. Potential quality issues detected and corrected`)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>AI Control Panel</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="space-y-2">
            <Textarea
              placeholder="Enter your query for the AI system"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              rows={4}
            />
          </div>
          <Button onClick={handleAIQuery}>Submit Query</Button>
          {aiResponse && (
            <div className="mt-4 p-4 bg-muted rounded-lg">
              <h3 className="font-semibold mb-2">AI Response:</h3>
              <p className="whitespace-pre-line">{aiResponse}</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}


"use client"

import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"

export default function ProductionLineSelector() {
  const [selectedLine, setSelectedLine] = useState<string | undefined>()

  const handleLineSelect = (value: string) => {
    setSelectedLine(value)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Production Line Selector</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Select onValueChange={handleLineSelect}>
            <SelectTrigger>
              <SelectValue placeholder="Select a production line" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="line1">Production Line 1</SelectItem>
              <SelectItem value="line2">Production Line 2</SelectItem>
              <SelectItem value="line3">Production Line 3</SelectItem>
            </SelectContent>
          </Select>
          <Button disabled={!selectedLine}>Load Production Line</Button>
        </div>
      </CardContent>
    </Card>
  )
}


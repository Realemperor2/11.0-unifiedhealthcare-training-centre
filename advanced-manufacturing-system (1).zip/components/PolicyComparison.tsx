"use client"

import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

interface Policy {
  name: string;
  coverage: string;
  premium: number;
  deductible: number;
}

const availablePolicies: Policy[] = [
  { name: "Basic Plan", coverage: "Essential", premium: 100, deductible: 500 },
  { name: "Standard Plan", coverage: "Comprehensive", premium: 200, deductible: 250 },
  { name: "Premium Plan", coverage: "Full", premium: 300, deductible: 100 },
]

export function PolicyComparison() {
  const [selectedPolicies, setSelectedPolicies] = useState<Policy[]>([])

  const addPolicy = (policyName: string) => {
    const policy = availablePolicies.find(p => p.name === policyName)
    if (policy && !selectedPolicies.includes(policy)) {
      setSelectedPolicies([...selectedPolicies, policy])
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Policy Comparison</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Select onValueChange={addPolicy}>
            <SelectTrigger>
              <SelectValue placeholder="Select a policy to compare" />
            </SelectTrigger>
            <SelectContent>
              {availablePolicies.map((policy) => (
                <SelectItem key={policy.name} value={policy.name}>{policy.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          {selectedPolicies.length > 0 && (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Policy Name</TableHead>
                  <TableHead>Coverage</TableHead>
                  <TableHead>Premium</TableHead>
                  <TableHead>Deductible</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {selectedPolicies.map((policy) => (
                  <TableRow key={policy.name}>
                    <TableCell>{policy.name}</TableCell>
                    <TableCell>{policy.coverage}</TableCell>
                    <TableCell>${policy.premium}</TableCell>
                    <TableCell>${policy.deductible}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
          <Button onClick={() => setSelectedPolicies([])}>Clear Comparison</Button>
        </div>
      </CardContent>
    </Card>
  )
}


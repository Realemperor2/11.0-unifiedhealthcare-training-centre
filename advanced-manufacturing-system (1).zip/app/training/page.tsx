import ProductionLineDesigner from '@/components/ProductionLineDesigner'
import VirtualEnvironment from '@/components/VirtualEnvironment'
import SkillAssessment from '@/components/SkillAssessment'
import TutorialGuide from '@/components/TutorialGuide'
import VoiceControlledTutorial from '@/components/VoiceControlledTutorial'
import { ARTrainingSimulator } from '@/components/ARTrainingSimulator'
import { PerformanceTracker } from '@/components/PerformanceTracker'

export default function TrainingPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">AR/VR Training Centre</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <ProductionLineDesigner />
        <VirtualEnvironment />
        <SkillAssessment />
        <TutorialGuide />
        <VoiceControlledTutorial />
        <ARTrainingSimulator />
        <PerformanceTracker />
      </div>
    </div>
  )
}


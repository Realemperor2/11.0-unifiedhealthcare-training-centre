import { Universal3DPrinter } from '@/components/Universal3DPrinter'
import { MaterialSelector } from '@/components/MaterialSelector'
import { PrintJobManager } from '@/components/PrintJobManager'
import { AIControlPanel } from '@/components/AIControlPanel'

export default function Universal3DPrinterPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Universal 3D Printer 2.0</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Universal3DPrinter />
        <MaterialSelector />
        <PrintJobManager />
        <AIControlPanel />
      </div>
    </div>
  )
}


import { Printer3DViewer } from '@/components/Printer3DViewer'
import { MaterialSelector } from '@/components/MaterialSelector'
import { PrintJobManager } from '@/components/PrintJobManager'
import { AIControlPanel } from '@/components/AIControlPanel'
import { AdvancedSettings } from '@/components/AdvancedSettings'

export default function Printer3DPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">3D Printer 3.0</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Printer3DViewer />
        <MaterialSelector />
        <PrintJobManager />
        <AIControlPanel />
        <AdvancedSettings />
      </div>
    </div>
  )
}


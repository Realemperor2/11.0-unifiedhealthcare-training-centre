import ProductionDesigner from '@/components/ProductionDesigner'
import SimulationEnvironment from '@/components/SimulationEnvironment'
import PrinterControl from '@/components/PrinterControl'
import AIAssistant from '@/components/AIAssistant'
import QualityControl from '@/components/QualityControl'
import { TeamAnalysis } from '@/components/TeamAnalysis'
import { PredictiveMaintenance } from '@/components/PredictiveMaintenance'

export default function ProductionPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Production Line Management</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <ProductionDesigner />
        <SimulationEnvironment />
        <PrinterControl />
        <AIAssistant />
        <QualityControl />
        <PredictiveMaintenance />
        <TeamAnalysis />
      </div>
    </div>
  )
}


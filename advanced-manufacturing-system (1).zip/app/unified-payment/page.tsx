import { PaymentDashboard } from '@/components/PaymentDashboard'
import { PaymentForm } from '@/components/PaymentForm'
import { TransactionHistory } from '@/components/TransactionHistory'
import { PaymentAnalytics } from '@/components/PaymentAnalytics'

export default function UnifiedPaymentPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Unified Payment System</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <PaymentDashboard />
        <PaymentForm />
        <TransactionHistory />
        <PaymentAnalytics />
      </div>
    </div>
  )
}


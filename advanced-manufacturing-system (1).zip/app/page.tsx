import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'
import { Canvas } from '@react-three/fiber'
import { OrbitControls, Sphere, Text } from '@react-three/drei'

const data = [
  { name: 'Healthcare', value: 400, color: '#FF6384' },
  { name: 'Training', value: 300, color: '#36A2EB' },
  { name: 'Insurance', value: 200, color: '#FFCE56' },
  { name: 'Production', value: 500, color: '#4BC0C0' },
  { name: 'Software', value: 350, color: '#9966FF' },
  { name: 'Raw Materials', value: 250, color: '#FF9F40' },
  { name: '3D Printer 2.0', value: 600, color: '#FF6384' },
  { name: 'Unified Payment', value: 450, color: '#36A2EB' },
  { name: '3D Printer 3.0', value: 700, color: '#FFCE56' },
];

function DashboardModel() {
  return (
    <>
      <ambientLight intensity={0.5} />
      <pointLight position={[10, 10, 10]} />
      <Sphere args={[1, 32, 32]}>
        <meshStandardMaterial color="blue" />
      </Sphere>
      <Text position={[0, 1.5, 0]} fontSize={0.5} color="white">
        AMS Dashboard
      </Text>
      <OrbitControls />
    </>
  )
}

export default function DashboardPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Advanced Manufacturing System Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>System Overview</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="value" fill="#8884d8" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Resource Allocation</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={data}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {data.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>3D Dashboard Model</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <Canvas>
                <DashboardModel />
              </Canvas>
            </div>
          </CardContent>
        </Card>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {data.map((section) => (
          <Link key={section.name} href={`/${section.name.toLowerCase().replace(' ', '-').replace('.', '')}`}>
            <Card className="hover:shadow-lg transition-shadow duration-300 cursor-pointer">
              <CardHeader>
                <CardTitle>{section.name}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center">
                  <span className="text-2xl font-bold">{section.value}</span>
                  <div className="w-4 h-4 rounded-full" style={{ backgroundColor: section.color }}></div>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  )
}


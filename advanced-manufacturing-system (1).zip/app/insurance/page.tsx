import { PolicyManagement } from '@/components/PolicyManagement'
import { ClaimProcessing } from '@/components/ClaimProcessing'
import { RiskAssessment } from '@/components/RiskAssessment'
import { PolicyComparison } from '@/components/PolicyComparison'

export default function InsurancePage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Insurance Management</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <PolicyManagement />
        <ClaimProcessing />
        <RiskAssessment />
        <PolicyComparison />
      </div>
    </div>
  )
}


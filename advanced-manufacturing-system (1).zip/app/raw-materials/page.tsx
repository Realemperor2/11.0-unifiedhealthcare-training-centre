import { InventoryManagement } from '@/components/InventoryManagement'
import { SupplyChainTracking } from '@/components/SupplyChainTracking'
import { QualityAssurance } from '@/components/QualityAssurance'
import { RawMaterialsPreprocessor } from '@/components/RawMaterialsPreprocessor'

export default function RawMaterialsPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Raw Materials Management</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <InventoryManagement />
        <SupplyChainTracking />
        <QualityAssurance />
        <RawMaterialsPreprocessor />
      </div>
    </div>
  )
}


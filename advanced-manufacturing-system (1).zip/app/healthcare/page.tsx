import { HealthRecordSystem } from '@/components/HealthRecordSystem'
import { TelehealthInterface } from '@/components/TelehealthInterface'
import { HealthcareAIAssistant } from '@/components/HealthcareAIAssistant'
import { MedicalImageAnalysis } from '@/components/MedicalImageAnalysis'
import { HealthMetricsMonitor } from '@/components/HealthMetricsMonitor'
import { PatientAppointments } from '@/components/PatientAppointments'

export default function HealthcarePage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Unified Healthcare</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <HealthRecordSystem />
        <TelehealthInterface />
        <HealthcareAIAssistant />
        <MedicalImageAnalysis />
        <HealthMetricsMonitor />
        <PatientAppointments />
      </div>
    </div>
  )
}


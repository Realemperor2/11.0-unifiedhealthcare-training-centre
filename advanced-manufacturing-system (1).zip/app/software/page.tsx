import { CodeGenerator } from '@/components/CodeGenerator'
import { VersionControl } from '@/components/VersionControl'
import { ContinuousIntegration } from '@/components/ContinuousIntegration'
import { TeamAnalysis } from '@/components/TeamAnalysis'
import { AICodeReview } from '@/components/AICodeReview'
import { AIModelDevelopment } from '@/components/AIModelDevelopment'
import { ModelDeployment } from '@/components/ModelDeployment'
import { AgentCreation } from '@/components/AgentCreation'
import { AppGenerator } from '@/components/AppGenerator'

export default function SoftwarePage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Software Factory</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <CodeGenerator />
        <VersionControl />
        <ContinuousIntegration />
        <AICodeReview />
        <AIModelDevelopment />
        <ModelDeployment />
        <AgentCreation />
        <TeamAnalysis />
      </div>
      <AppGenerator />
    </div>
  )
}


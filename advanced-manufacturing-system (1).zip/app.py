import os
import io
import subprocess
import requests
import json
import tensorflow as tf
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
import pyaudio
import speech_recognition as sr
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, LSTM, Dense
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from google.cloud import vision
from openai import OpenAI
from fastapi import FastAPI, File, UploadFile, HTTPException, Depends
from fastapi.security import APIKeyHeader
from pydantic import BaseModel
import uvicorn
from typing import List, Optional

# Set API keys as environment variables
APPLICATION_ID = os.getenv("APPLICATION_ID")
CLIENT_KEY = os.getenv("CLIENT_KEY")
JAVASCRIPT_KEY = os.getenv("JAVASCRIPT_KEY")
DOTNET_KEY = os.getenv("DOTNET_KEY")
REST_API_KEY = os.getenv("REST_API_KEY")
WEBHOOK_KEY = os.getenv("WEBHOOK_KEY")
FILE_KEY = os.getenv("FILE_KEY")
NVIDIA_MAISI_API_KEY = os.getenv("NVIDIA_MAISI_API_KEY")
NVIDIA_VISTA_3D_API_KEY = os.getenv("NVIDIA_VISTA_3D_API_KEY")
NVIDIA_PALMYRA_MED_API_KEY = os.getenv("NVIDIA_PALMYRA_MED_API_KEY")
NVIDIA_ALPHAFOLD2_API_KEY = os.getenv("NVIDIA_ALPHAFOLD2_API_KEY")
NVIDIA_VILA_API_KEY = os.getenv("NVIDIA_VILA_API_KEY")
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")

if not all([APPLICATION_ID, CLIENT_KEY, JAVASCRIPT_KEY, DOTNET_KEY, REST_API_KEY, WEBHOOK_KEY, FILE_KEY,
            NVIDIA_MAISI_API_KEY, NVIDIA_VISTA_3D_API_KEY, NVIDIA_PALMYRA_MED_API_KEY, NVIDIA_ALPHAFOLD2_API_KEY, NVIDIA_VILA_API_KEY, GOOGLE_API_KEY]):
    raise ValueError("All required environment variables must be set")

# Initialize OpenAI client
openai_client = OpenAI(
  base_url="https://integrate.api.nvidia.com/v1",
  api_key=REST_API_KEY
)

# Create a client instance for Google Cloud Vision API
vision_client = vision.ImageAnnotatorClient()

# Create a speech recognition instance
r = sr.Recognizer()

# Create a tokenizer instance
tokenizer = Tokenizer(num_words=10000)

# Load text data
text_data = ['This is a positive review.', 'This is a negative review.']

# Fit tokenizer to text data
tokenizer.fit_on_texts(text_data)

# Convert text data to sequences
sequences = tokenizer.texts_to_sequences(text_data)

# Pad sequences to uniform length
padded_sequences = pad_sequences(sequences, maxlen=200)

# Create a sentiment analysis model
model = Sequential([
    Embedding(input_dim=10000, output_dim=128, input_length=200),
    LSTM(units=128, dropout=0.2),
    Dense(units=1, activation='sigmoid')
])

# Compile model
model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])

# Train model
model.fit(padded_sequences, epochs=10, batch_size=32)

# Define API endpoint
app = FastAPI()

# API Key security
api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)

async def get_api_key(api_key_header: str = Depends(api_key_header)):
    if api_key_header == REST_API_KEY:
        return api_key_header
    raise HTTPException(status_code=403, detail="Could not validate credentials")

class PromptRequest(BaseModel):
    prompt: str

class MaisiRequest(BaseModel):
    body_region: List[str]
    anatomy_list: List[str]
    controllable_anatomy_size: List[List[float]]
    output_size: List[int]
    spacing: List[float]

class Vista3DRequest(BaseModel):
    image_url: str
    classes: List[str]

class AlphaFold2Request(BaseModel):
    sequences: List[str]

class VilaRequest(BaseModel):
    query: str
    image_url: str

@app.post("/generate_text")
async def generate_text_endpoint(request: PromptRequest, api_key: str = Depends(get_api_key)):
    try:
        completion = openai_client.chat.completions.create(
            model="meta/llama-3.3-70b-instruct",
            messages=[{"role":"user","content":request.prompt}],
            temperature=0.2,
            top_p=0.7,
            max_tokens=1024,
            stream=True
        )
        text = ""
        for chunk in completion:
            if chunk.choices[0].delta.content is not None:
                text += chunk.choices[0].delta.content
        return {"text": text}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/image_recognition")
async def image_recognition_endpoint(file: UploadFile = File(...), api_key: str = Depends(get_api_key)):
    try:
        content = await file.read()
        image = vision.Image(content=content)
        response = vision_client.label_detection(image=image)
        labels = [label.description for label in response.label_annotations]
        return {"labels": labels}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/object_detection")
async def object_detection_endpoint(file: UploadFile = File(...), api_key: str = Depends(get_api_key)):
    try:
        content = await file.read()
        api_endpoint = 'https://api.nvidia.com/v1/hosted-api/object-detection'
        headers = {
            'Authorization': f'Bearer {REST_API_KEY}',
            'Content-Type': 'application/octet-stream'
        }
        response = requests.post(api_endpoint, headers=headers, data=content)
        response.raise_for_status()
        response_data = response.json()
        objects = [{"class": obj['class'], "confidence": obj['confidence']} for obj in response_data['objects']]
        return {"objects": objects}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/sentiment_analysis")
async def sentiment_analysis_endpoint(request: PromptRequest, api_key: str = Depends(get_api_key)):
    try:
        sequence = tokenizer.texts_to_sequences([request.prompt])
        padded_sequence = pad_sequences(sequence, maxlen=200)
        prediction = model.predict(padded_sequence)
        return {"sentiment": float(prediction[0][0])}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/speech_recognition")
async def speech_recognition_endpoint(file: UploadFile = File(...), api_key: str = Depends(get_api_key)):
    try:
        content = await file.read()
        with open("temp_audio.wav", "wb") as f:
            f.write(content)
        with sr.AudioFile("temp_audio.wav") as source:
            audio = r.record(source)
        text = r.recognize_google(audio, key=GOOGLE_API_KEY)
        return {"text": text}
    except sr.UnknownValueError:
        raise HTTPException(status_code=400, detail="Google Speech Recognition could not understand audio")
    except sr.RequestError as e:
        raise HTTPException(status_code=500, detail=f"Could not request results from Google Speech Recognition service; {e}")
    finally:
        if os.path.exists("temp_audio.wav"):
            os.remove("temp_audio.wav")

@app.post("/maisi")
async def maisi_endpoint(request: MaisiRequest, api_key: str = Depends(get_api_key)):
    try:
        api_endpoint = 'https://health.api.nvidia.com/v1/medicalimaging/nvidia/maisi'
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {NVIDIA_MAISI_API_KEY}'
        }
        data = {
            "num_output_samples": 1,
            "body_region": request.body_region,
            "anatomy_list": request.anatomy_list,
            "controllable_anatomy_size": request.controllable_anatomy_size,
            "output_size": request.output_size,
            "output_ext": ".nii.gz",
            "pre_signed_url": "",
            "spacing": request.spacing,
        }
        response = requests.post(api_endpoint, headers=headers, json=data)
        response.raise_for_status()
        return response.json()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/vista3d")
async def vista3d_endpoint(request: Vista3DRequest, api_key: str = Depends(get_api_key)):
    try:
        api_endpoint = 'https://health.api.nvidia.com/v1/medicalimaging/nvidia/vista-3d'
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {NVIDIA_VISTA_3D_API_KEY}'
        }
        data = {
            "image": request.image_url,
            "prompts": {
                "classes": request.classes,
            }
        }
        response = requests.post(api_endpoint, headers=headers, json=data)
        response.raise_for_status()
        return response.json()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/palmyra_med")
async def palmyra_med_endpoint(request: PromptRequest, api_key: str = Depends(get_api_key)):
    try:
        completion = openai_client.chat.completions.create(
            model="writer/palmyra-med-70b",
            messages=[{"role":"user","content":request.prompt}],
            temperature=0.2,
            top_p=0.7,
            max_tokens=1024,
            stream=True
        )
        text = ""
        for chunk in completion:
            if chunk.choices[0].delta.content is not None:
                text += chunk.choices[0].delta.content
        return {"text": text}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/alphafold2")
async def alphafold2_endpoint(request: AlphaFold2Request, api_key: str = Depends(get_api_key)):
    try:
        api_endpoint = 'https://health.api.nvidia.com/v1/biology/deepmind/alphafold2-multimer'
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {NVIDIA_ALPHAFOLD2_API_KEY}'
        }
        data = {
            "sequences": request.sequences,
            "algorithm": "jackhmmer",
            "e_value": 0.0001,
            "iterations": 1,
            "databases": ["uniref90", "small_bfd", "mgnify"],
            "relax_prediction": True,
        }
        response = requests.post(api_endpoint, headers=headers, json=data)
        response.raise_for_status()
        if response.status_code == 202:
            return {"status": "accepted", "req_id": response.headers.get("nvcf-reqid")}
        return response.json()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/vila")
async def vila_endpoint(request: VilaRequest, api_key: str = Depends(get_api_key)):
    try:
        api_endpoint = 'https://ai.api.nvidia.com/v1/vlm/nvidia/vila'
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {NVIDIA_VILA_API_KEY}'
        }
        data = {
            "max_tokens": 1024,
            "temperature": 0.2,
            "top_p": 0.7,
            "seed": 50,
            "num_frames_per_inference": 8,
            "messages": [
                {
                    "role": "user",
                    "content": f"{request.query} <img src='{request.image_url}' />"
                }
            ],
            "stream": False,
            "model": "nvidia/vila"
        }
        response = requests.post(api_endpoint, headers=headers, json=data)
        response.raise_for_status()
        return response.json()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Install dependencies
def install_dependencies():
    subprocess.run(["pip", "install", "openai", "fastapi", "uvicorn", "pydantic", "google-cloud-vision", "tensorflow", "nltk", "pyaudio", "SpeechRecognition", "python-multipart"])

# Create vercel.json
def create_vercel_json():
    with open("vercel.json", "w") as f:
        f.write('{"version": 2, "builds": [{"src": "app.py", "use": "@vercel/python"}], "routes": [{"src": "/(.*)", "dest": "app.py"}]}')

# Run development server
def run_server():
    uvicorn.run(app, host="0.0.0.0", port=8000)

# Main function
def main():
    install_dependencies()
    create_vercel_json()
    nltk.download('punkt')
    nltk.download('stopwords')
    nltk.download('wordnet')
    run_server()

if __name__ == "__main__":
    main()


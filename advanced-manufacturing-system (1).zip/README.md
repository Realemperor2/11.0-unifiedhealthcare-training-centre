# Advanced Manufacturing System

This project is an integrated platform for managing various aspects of advanced manufacturing, including healthcare, training, insurance, production line management, software development, and raw materials management.

## Project Structure

The project consists of two main parts:

1. Frontend: A Next.js application with React components for different sections of the manufacturing system.
2. Backend: A FastAPI application providing various AI capabilities.

## Frontend

The frontend is built with Next.js and includes the following main sections:

- Unified Healthcare
- Training Centre
- Insurance
- Production Line
- Software Factory
- Raw Materials

Each section is represented by a separate page in the `app` directory and uses components from the `components` directory.

## Backend

The backend is a FastAPI application (`app.py`) that provides API endpoints for various AI capabilities:

1. Text Generation: Uses NVIDIA's API to generate text based on prompts.
2. Image Recognition: Uses Google Cloud Vision API to recognize labels in images.
3. Object Detection: Uses NVIDIA's API to detect objects in images.
4. Sentiment Analysis: Uses a custom-trained model to analyze sentiment in text.
5. Speech Recognition: Uses Google's Speech Recognition API to convert speech to text.

### Setup

1. Install dependencies:


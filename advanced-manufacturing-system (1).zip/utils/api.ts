// Placeholder values
const PLACEHOLDER_API_BASE_URL = 'https://api.example.com';
const PLACEHOLDER_OPENAI_API_KEY = 'sk-placeholder-api-key';

// Use real environment variables if available, otherwise use placeholders
const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || PLACEHOLDER_API_BASE_URL;
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || PLACEHOLDER_OPENAI_API_KEY;

export async function apiRequest(endpoint: string, method: string = 'GET', body?: any) {
  const url = `${API_BASE_URL}${endpoint}`;
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${OPENAI_API_KEY}`
  };

  const options: RequestInit = {
    method,
    headers,
    body: body instanceof FormData ? body : body ? JSON.stringify(body) : undefined,
  };

  try {
    // Check if we're using placeholder values and log a warning
    if (API_BASE_URL === PLACEHOLDER_API_BASE_URL || OPENAI_API_KEY === PLACEHOLDER_OPENAI_API_KEY) {
      console.warn('Using placeholder API values. Set up your environment variables for full functionality.');
    }

    const response = await fetch(url, options);

    if (!response.ok) {
      throw new Error(`API request failed: ${response.statusText}`);
    }

    return response.json();
  } catch (error) {
    console.error('API request error:', error);
    throw error;
  }
}

